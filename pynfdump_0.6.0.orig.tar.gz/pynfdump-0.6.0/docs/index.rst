.. pynfdump documentation master file, created by sphinx-quickstart on Mon Mar 23 11:14:23 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pynfdump's documentation!
====================================
pynfdump is a wrapper around the `NFDUMP <http://nfdump.sourceforge.net/>`_ program.

It supports normal, aggregation, and statistics modes.
It supports running nfdump on a remote host via ssh.

Contents:

.. toctree::
   :maxdepth: 2

   usage
   api
   download
   changes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

